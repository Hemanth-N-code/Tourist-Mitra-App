
import React from "react";
import TouristSafetyPrototype from "./TouristSafetyPrototype";

function App() {
  return <TouristSafetyPrototype />;
}

export default App;
